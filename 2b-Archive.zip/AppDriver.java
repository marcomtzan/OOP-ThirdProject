/**   
   @author       Marco Martinez
   @fileName     AppDriver.java
   @version      1.0
   @description  This program will utilize Employees objects for creating a report.
   
   Classes
      EmployeeRecord
      Employee
      Employees
      AppDriver
   
   Associations
      EmployeeRecord(1) --- includes --- (1) Employee
      Employees(1) --- contains --- (m) Employee
      AppDriver(1) --- uses --- (1) Employees
   
   AppDriver Class
      (+) static void getEmployees(Employees myEmps)
      (+) static String validateString(String name, Scanner input)
      (+) static double validateDouble(double value, Scanner input)
      (+) static char validateChar(char c, Scanner input)
      (+) static void printReport(Employees myEmps)
      (+) static void printHeading()
      (+) static void printLabels()
      (+) static void printEmployees(Employees myEmps)
      (+) static void printFooter(Employees myEmps)
      (+) static void printString38(String str)
      (+) static void printString12(String str)
      (+) static void printDouble12(double value)
      (+) static String concatenateName(String lastName, String firstName)

   
   @date         10/11/2018

   Program Change Log 
   ==========================
   Name     Date     Description
   Marco    10/11    Create baseline for AppDriver.
   Marco    10/28    Add finishing touches to AppDriver.
 */
 // LIBRARIES
import java.util.Scanner; // Allows access to scanner

public class AppDriver
{
   public static void main(String[] args) 
   {
      // VARIABLE DECLARATIONS
      Employees myEmps = new Employees();
      
      // CALLS
      getEmployees(myEmps); 
      myEmps.sort();
      printReport(myEmps);
   }
   
   // METHODS
   // (+) static void getEmployees(Employees myEmps)
   public static void getEmployees(Employees myEmps)
   {
      Scanner input = new Scanner(System.in);
      char c = 'y';
      String tempFirstName;
      String tempLastName;
      double tempHrsWkd;
      double tempPayRate;

	   while (c != 'n' && c != 'N') 
      {
         tempFirstName = new String("");
         tempLastName = new String("");
         tempHrsWkd = 0.00;
         tempPayRate = 0.00;
         
		   System.out.print("Please enter the employee's first name here: ");
         tempFirstName = validateString(input.next(), input);
         
		   System.out.print("Please enter the employee's last name here: ");
         tempLastName = validateString(input.next(), input);
         
		   System.out.print("Please enter the employee's hourly pay here: ");
		   tempPayRate = validateDouble(input.nextDouble(), input);
         
         System.out.print("Please enter the employee's number of worked hours: ");
		   tempHrsWkd = validateDouble(input.nextDouble(), input);
         
         myEmps.add(tempLastName, tempFirstName, tempHrsWkd, tempPayRate);

		   System.out.print("Would you like to continue? (Y/N) ");
         c = validateChar((input.next().charAt(0)), input);
         System.out.println();

         if (myEmps.getLength() >= myEmps.EMPMAX - 1) 
         {
		   	System.out.println("You have hit the maximum amount of employees to enter.");
            c = 'n';
         }
      }
      input.close();
   }
   
   // (+) static String validateString(String name, Scanner input)
   public static String validateString(String name, Scanner input)
   {   
      for(int i = 0; i < 3; i++)
      {
         if (name.matches("[a-zA-Z]+")) return name;
         System.out.println("Error. A name must be alphanumeric.");
         System.out.print("Please enter a name with the correct specifications: ");
         name = input.next();
      }
      
      return "Default";
   }
   
   // (+) static double validateDouble(double value, Scanner input)
   public static double validateDouble(double value, Scanner input)
   {  
      for(int i = 0; i < 3; i++)
      {
         if (value > 0.00) return value;
         System.out.println("Error. Value must be more than 0.");
         System.out.print("Please enter a value with the correct specifications: ");
         value = input.nextDouble();
      }
      
      return 0.00;
   }
   
   // (+) static char validateChar(char c, Scanner input)
   public static char validateChar(char c, Scanner input)
   {
      while (c != 'n' && c != 'N' && c != 'y' && c != 'Y') 
      {
		   System.out.println("Invalid input.");
			System.out.print("Please enter either a 'y' or 'n': ");
			c = input.next().charAt(0);
         System.out.println();
		}
      
      return c;
   }
   
   // (+) static void printReport(Employees myEmps)
   public static void printReport(Employees myEmps)
   {
      printHeading();
      printLabels();
      printEmployees(myEmps);
      printFooter(myEmps);
   }
   
   // (+) static void printHeading()
   public static void printHeading()
   {
      System.out.println("==================================================================================================");
		System.out.println("                                  YOUR FINANCIAL REPORT ANALYSIS                                  ");
		System.out.println("==================================================================================================");
		System.out.println();
   }
   
   // (+) static void printLabels()
   public static void printLabels()
   {
      printString38("Employee");
      printString12("Pay");
      printString12("Hours");
      printString12("Gross");
      printString12("Tax");
      printString12("Net");
      System.out.println();
		printString38("Name");
      printString12("Rate");
      printString12("Worked");
      printString12("Pay");
      printString12("Amount");
      printString12("Pay");
      System.out.println();
		printString38("=====");
      printString12("=====");
      printString12("=====");
      printString12("=====");
      printString12("=====");
      printString12("=====");
      System.out.println();
   }
   
   // (+) static void printEmployees(Employees myEmps)
   public static void printEmployees(Employees myEmps)
   {
      while(myEmps.hasNext())
      {
         EmployeeRecord tempRecord = new EmployeeRecord(myEmps.iterate());
         printString38(concatenateName(tempRecord.lastName, tempRecord.firstName));
         printDouble12(tempRecord.payRate);
         printDouble12(tempRecord.hrsWkd);
         printDouble12(tempRecord.grossPay);
         printDouble12(tempRecord.taxAmt);
         printDouble12(tempRecord.netPay);
         System.out.println();
      }
   }
   
   // (+) static void printFooter(Employees myEmps)
   public static void printFooter(Employees myEmps)
   {
      
      double totalHrsWkd = 0;
      double totalPayRate = 0;
      double totalGrossPay = 0;
      double totalTaxAmt = 0;
      double totalNetPay = 0;
   
      while(myEmps.hasNext())
      {
         EmployeeRecord tempRecord = new EmployeeRecord(myEmps.iterate());
         totalPayRate += tempRecord.payRate;
         totalHrsWkd += tempRecord.hrsWkd;
         totalGrossPay += tempRecord.grossPay;
         totalTaxAmt += tempRecord.taxAmt;
         totalNetPay += tempRecord.netPay;
      }
      
      printString38("Totals:");
      printDouble12(totalPayRate);
      printDouble12(totalHrsWkd);
      printDouble12(totalGrossPay);
      printDouble12(totalTaxAmt);
      printDouble12(totalNetPay);
      System.out.println();
      
      printString38("Averages:");
      printDouble12(totalPayRate/myEmps.getLength());
      printDouble12(totalHrsWkd/myEmps.getLength());
      printDouble12(totalGrossPay/myEmps.getLength());
      printDouble12(totalTaxAmt/myEmps.getLength());
      printDouble12(totalNetPay/myEmps.getLength());
      System.out.println();
   }
   
   // (+) static void printString38(String str)
   public static void printString38(String str)
   {
      System.out.printf("%-38s", str);
   }

   // (+) static void printString12(String str)
   public static void printString12(String str)
   {
      System.out.printf("%12s", str);
   }
   
   // (+) static void printDouble12(double value)
   public static void printDouble12(double value)
   {
      System.out.printf("%12.2f", value);
   }
   
   // (+) static String concatenateName(String lastName, String firstName)
   public static String concatenateName(String lastName, String firstName)
   {
      return lastName + ", " + firstName;
   }
}