/**   
   @author       Marco Martinez
   @fileName     Employees.java
   @version      1.0
   @description  This program will construct and manipulate Employees objects.
   
   Classes
      EmployeeRecord
      Employee
      Employees
      AppDriver
   
   Associations
      EmployeeRecord(1) --- includes --- (1) Employee
      Employees(1) --- contains --- (m) Employee
      AppDriver(1) --- uses --- (1) Employees
   
   Employees Class Attributes
      INSTANCE VARIABLES
      (-) EmployeeRecord[] emps
      (-) int index
      (-) int currentIndex
   
      CLASS CONSTRUCTORS
      (+) Employees()
      (+) Employees(String lastName, String firstName, double hrsWkd, double payRate)
      (+) Employees(EmployeeRecord newEmployeeRecord)
      (+) Employees(Employee newEmployee)
      (+) Employees(Employee[] newEmployee, int newIndex)
      (+) Employees(Employees newEmployees)
      
      CHANGE STATE SERVICES
      (+) void add(String lastName, String firstName, double hrsWkd, double payRate)
      (+) void add(EmployeeRecord e)
      (+) void add(Employee e)
      (+) void add(Employees newEmployees)
      (+) void delete(String lastName)
      (+) void delete(int eID)
      (+) void sort()
      (-) void qSort(int start, int finish)
      
      READ STATE SERVICES
      (+) int getLength()
      (+) Employee[] getEmp()
      (+) Employee getEmp(int indexPoint)
      (+) EmployeeRecord search(int eID)
      (+) EmployeeRecord search(String lastName)
      (-) EmployeeRecord biSearch(int key, int low, int high)
      (-) EmployeeRecord biSearch(String key, int low, int high)
      (+) EmployeeRecord iterate()
      (+) boolean hasNext()
      (+) String toString()
   
   @date         10/11/2018

   Program Change Log 
   ==========================
   Name     Date     Description
   Marco    10/11    Create baseline for Employees.
   Marco    10/28    Add finishing touches to Employees.
 */
 
public class Employees
{
   // CONSTANT DEFINITIONS
   public static final int EMPMAX = 100;
   
   // INSTANCE VARIABLE INITIALIZATIONS
   private Employee emps[] = new Employee[EMPMAX];
   private int index = 0;
   private int currentIndex = 0;
   
   // CLASS CONSTRUCTORS
   // (+) Employees() 				
   public Employees(){}

   // (+) Employees(String lastName, String firstName, double hrsWkd, double payRate)				
   public Employees(String lastName, String firstName, double hrsWkd, double payRate)
   {
      this.emps[this.index] = new Employee(lastName, firstName, hrsWkd, payRate);
      (this.emps[this.index].get()).employeeNumber = this.index;
      this.index++;
   }
   
   // (+) Employees(EmployeeRecord newEmployeeRecord)
   public Employees(EmployeeRecord newEmployeeRecord)
   {
      this.emps[this.index] = new Employee(newEmployeeRecord);
      (this.emps[this.index].get()).employeeNumber = this.index;
      this.index++;
   }
  
   // (+) Employees(Employee newEmployee)
   public Employees(Employee newEmployee)
   {
      this.emps[this.index] = new Employee(newEmployee);
      (this.emps[this.index].get()).employeeNumber = this.index;
      this.index++;
   }
   
   // (+) Employees(Employee[] newEmployee, int newIndex)
   public Employees(Employee[] newEmployee, int newIndex)
   { 
      if (newIndex < EMPMAX)
      {
         for (int i = 0; i < newIndex; i++)
         {
            this.emps[i] = newEmployee[i];
            (this.emps[i].get()).employeeNumber = i;
         }
      
         this.index = newIndex;
      }
   }
   
   // (+) Employees(Employees newEmployees)
   public Employees(Employees newEmployees)
   {
      if (newEmployees.getLength() < EMPMAX)
      {
         for(int i = 0; i < newEmployees.getLength(); i++)
         {
            this.emps[this.index] = newEmployees.getEmp(i);
            (this.emps[this.index].get()).employeeNumber = this.index;
            this.index++;
         }
      }

   }
   
   // CHANGE STATE SERVICES
   // (+) void add(String lastName, String firstName, double hrsWkd, double payRate)
   public void add(String lastName, String firstName, double hrsWkd, double payRate)
   {  
      this.emps[this.index] = new Employee(lastName, firstName, hrsWkd, payRate);
      (this.emps[this.index].get()).employeeNumber = this.index;
      this.index++;
   }
   
   
   // (+) void add(EmployeeRecord e)
   public void add(EmployeeRecord e)
   {  
      this.emps[this.index] = new Employee(e);
      (this.emps[this.index].get()).employeeNumber = this.index;
      this.index++;
   }
   
   // (+) void add(Employee e)
   public void add(Employee e)
   {  
      this.emps[this.index] = new Employee(e);
      (this.emps[this.index].get()).employeeNumber = this.index;
      this.index++;
   }
   
   // (+) void add(Employees newEmployees)
   public void add(Employees newEmployees)
   {  
      System.out.println(Integer.toString(newEmployees.getLength()));
      if (this.index + newEmployees.getLength() < EMPMAX)
      {
         for(int i = 0; i < newEmployees.getLength(); i++)
         {
            this.emps[this.index] = newEmployees.getEmp(i);
            (this.emps[this.index].get()).employeeNumber = this.index;
            this.index++;
         }
      }
   }
   
   // (+) void delete(int eID)
   public void delete(int eID)
   {
      if ((search(eID).lastName) != null)
      {
         this.emps[search(eID).employeeNumber] = this.emps[index-1];
         this.emps[index-1] = new Employee();
         this.index--;
      }
      else return;
   }
   
   // (+) void delete(String lastName)
   public void delete(String lastName)
   {
      if ((search(lastName).lastName) != null)
      {
         this.emps[(search(lastName)).employeeNumber] = this.emps[index-1];
         this.emps[index-1] = new Employee();
         this.index--;
      }
      else return;
   }
   
   // (+) void sort()
   public void sort()
   {
      if (this.index > 0) qSort(0, this.index-1);
   }
   
   // (-)  void qSort(int start, int finish)
   private void qSort(int start, int finish)
   {
      int i = start;
      int j = finish;
      String pivot = (this.emps[start + (finish - start) / 2].get()).lastName;

      while (i <= j) 
      {
         while ((this.emps[i].get()).lastName.compareToIgnoreCase(pivot) < 0) 
         {
            i++;
         }

         while ((this.emps[j].get()).lastName.compareToIgnoreCase(pivot) > 0) 
         {
            j--;
         }

         if (i <= j) 
         {
            Employee temp = new Employee(this.emps[i]);
            this.emps[i] = new Employee(this.emps[j]);
            this.emps[j] = new Employee(temp);
            i++;
            j--;
         }
      }
    
        if (start < j) {
            qSort(start, j);
        }
        if (i < finish) {
            qSort(i, finish);
        }
        
        for(int n = 0; n < this.index; n++) (this.emps[n].get()).employeeNumber = n;
   }
   
   // READ STATE SERVICES
   // (+) int getLength()
   public int getLength()
   {
      return this.index;
   }
   
   // (+) Employee[] getEmp()
   public Employee[] getEmp()
   {
      return this.emps;
   }
   
   // (+) Employee getEmp(int indexPoint)
   public Employee getEmp(int indexPoint)
   {
      return this.emps[indexPoint];
   }
   
   // (+) EmployeeRecord search(int eID)
   public EmployeeRecord search(int eID)
   {
      return biSearch(eID, 0, this.index-1);
   }
   
   // (+) EmployeeRecord search(String lastName)
   public EmployeeRecord search(String lastName)
   {
      return biSearch(lastName, 0, this.index-1);
   }
   
   // (-)  EmployeeRecord biSearch(int key, int low, int high)
   private EmployeeRecord biSearch(int key, int low, int high)
   {       
      while(high >= low) 
      {
         int middle = (low + high) / 2;
         if ((this.emps[middle].get()).employeeNumber == key)
         {
            return this.emps[middle].get();
         }
         if ((this.emps[middle].get()).employeeNumber > key) 
         {
            return biSearch(key, low, middle-1);
         }
         if ((this.emps[middle].get()).employeeNumber < key) 
         {
            return biSearch(key, middle+1, high);
         }   
      }   
      return new EmployeeRecord();
   }
      
   // (-)  EmployeeRecord biSearch(String key, int low, int high)
   private EmployeeRecord biSearch(String key, int low, int high)
   {       
      while(high >= low) 
      {
         int middle = (low + high) / 2;
         if ((this.emps[middle].get()).lastName.compareToIgnoreCase(key) == 0)
         {
            return this.emps[middle].get();
         }
         if ((this.emps[middle].get()).lastName.compareToIgnoreCase(key) > 0) 
         {
            return biSearch(key, low, middle-1);
         }
         if ((this.emps[middle].get()).lastName.compareToIgnoreCase(key) < 0) 
         {
            return biSearch(key, middle+1, high);
         }   
      }   
      return new EmployeeRecord();
   }
   
   // (+) EmployeeRecord iterate()
   public EmployeeRecord iterate()
   {
      EmployeeRecord temp = new EmployeeRecord(this.emps[this.currentIndex].get());
      this.currentIndex++;
      return temp;
   }
   
   // (+) boolean hasNext()
   public boolean hasNext()
   {
      if ((search(this.currentIndex)).lastName != null)
      {
         return true;
      }
      else
      {
         this.currentIndex = 0;
         return false;
      }
   }
   
   // (+) String toString()
   public String toString()
   {
      String str = "" ;
      
      for(int i = 0; i < this.index; i++) str += "\n" + this.emps[i].toString();
      
      return str;
   }
}