/**   
   @author       Marco Martinez
   @fileName     EmployeeRecord.java
   @version      1.0
   @description  This program will construct and manipulate EmployeeRecord objects.
   
   Classes
      EmployeeRecord
      Employee
      Employees
      AppDriver
   
   Associations
      EmployeeRecord(1) --- includes --- (1) Employee
      Employees(1) --- contains --- (m) Employee
      AppDriver(1) --- uses --- (1) Employees
   
   EmployeeRecord Class Attributes
      INSTANCE VARIABLES
      (+) String lastName
      (+) String firstName
      (+) double hrsWkd
      (+) double payRate
      (+) double grossPay
      (+) double taxAmt
      (+) double netPay
      (+) int employeeNumber
      
      CLASS CONSTRUCTORS	
      (+) EmployeeRecord()
      (+) EmployeeRecord(String lastName, String firstName, double hrsWkd, double payRate)	
      (+) EmployeeRecord(EmployeeRecord e)
      
      READ STATE SERVICES
      (+) String toString()
   
   @date         10/11/2018

   Program Change Log 
   ==========================
   Name     Date     Description
   Marco    10/11    Create baseline for EmployeeRecord.
 */
 
public class EmployeeRecord
{
   // INSTANCE VARIABLE DECLARATIONS
   public String lastName,
                 firstName;
   public double hrsWkd,
                 payRate,
                 grossPay,
                 taxAmt,
                 netPay;
   public int    employeeNumber;

   // CLASS CONSTRUCTORS
   // (+) EmployeeRecord()  				
   public EmployeeRecord(){}

   // (+) EmployeeRecord(String newLastName, String newFirstName, double newHrsWkd, double newPayRate)				
   public EmployeeRecord(String newLastName, String newFirstName, double newHrsWkd, double newPayRate)
   {
      if (newHrsWkd < 0 || newPayRate < 0 || !newLastName.matches("[a-zA-Z]+") || !newFirstName.matches("[a-zA-Z]+")) return;
      else 
      {
         this.lastName = newLastName;
         this.firstName = newFirstName;
         this.hrsWkd = newHrsWkd;
         this.payRate = newPayRate;
         this.grossPay = this.taxAmt = this.netPay = 0;
      }
   }
    
   // (+) EmployeeRecord(EmployeeRecord newEmployeeRecord)
   public EmployeeRecord(EmployeeRecord newEmployeeRecord)
   {
      this.lastName = newEmployeeRecord.lastName;
      this.firstName = newEmployeeRecord.firstName;
      this.hrsWkd = newEmployeeRecord.hrsWkd;
      this.payRate = newEmployeeRecord.payRate;
      this.grossPay = newEmployeeRecord.grossPay;
      this.taxAmt = newEmployeeRecord.taxAmt;
      this.netPay = newEmployeeRecord.netPay;
   }
  
   // READ STATE SERVICES
   // (+) String toString()
   public String toString()
   {
      return this.lastName + ", " + this.firstName 
                           + " " + Double.toString(this.hrsWkd) 
                           + " " + Double.toString(this.payRate) 
                           + " " + Double.toString(this.grossPay) 
                           + " " + Double.toString(this.taxAmt) 
                           + " " + Double.toString(this.netPay);
   }
}